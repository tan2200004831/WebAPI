﻿using Microsoft.EntityFrameworkCore;
using NIIEPayAPI.Data;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers(); // API
builder.Services.AddControllersWithViews(); // Razor Views
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// DbContext
builder.Services.AddDbContext<NIIEPayContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// Swagger cho môi trường Development
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Các middleware
app.UseHttpsRedirection();
app.UseStaticFiles(); // <-- THÊM DÒNG NÀY nếu có dùng file tĩnh như .css, .js
app.UseRouting();
app.UseAuthorization();

// Map cả Controller API và View
app.MapControllers();             // map cho API Controller
app.MapDefaultControllerRoute();  // map cho MVC View (như /register)

// Chạy ứng dụng
app.Run();
