﻿using System.ComponentModel.DataAnnotations;

namespace NIIEPayAPI.Models
{
    public class InterestRate
    {
        [Key]
        public int TermMonths { get; set; }

        public double InterestRatePercent { get; set; }
    }
}
