﻿namespace NIIEPayAPI.Models
{
    public class TransferRequest
    {
        public string SenderAccount { get; set; }       // Số tài khoản người gửi
        public string ReceiverAccount { get; set; }     // STK hoặc SĐT người nhận
        public decimal Amount { get; set; }
        public string Note { get; set; }
        public bool IsPhoneNumber { get; set; }         // true nếu là SĐT
    }
}
