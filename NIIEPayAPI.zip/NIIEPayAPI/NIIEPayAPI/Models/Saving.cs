﻿using System.ComponentModel.DataAnnotations;

namespace NIIEPayAPI.Models
{
    public class Saving
    {
        [Key]
        public string SavingId { get; set; }

        public string AccountNumber { get; set; }

        public decimal Amount { get; set; }

        public int TermMonths { get; set; }

        public double InterestRate { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime MaturityDate { get; set; }

        public bool AutoRenew { get; set; }
    }
}
