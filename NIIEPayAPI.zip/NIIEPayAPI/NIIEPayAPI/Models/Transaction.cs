﻿using System.ComponentModel.DataAnnotations;

namespace NIIEPayAPI.Models
{
    public class Transaction
    {
        [Key]
        public string TransactionId { get; set; }

        public string AccountNumber { get; set; }

        public decimal Amount { get; set; }

        public DateTime TransactionTime { get; set; }

        public decimal BalanceAfter { get; set; }

        public string Note { get; set; }

        public string? TransactionType { get; set; } // "Internal" hoặc "External"
    }
}
