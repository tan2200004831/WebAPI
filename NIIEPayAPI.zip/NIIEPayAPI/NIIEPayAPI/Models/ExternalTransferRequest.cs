﻿namespace NIIEPayAPI.Models
{
    public class ExternalTransferRequest
    {
        public string SenderAccount { get; set; }
        public string ReceiverAccount { get; set; }
        public string BankName { get; set; }         // Tên ngân hàng nhận
        public decimal Amount { get; set; }
        public string Note { get; set; }
    }
}
