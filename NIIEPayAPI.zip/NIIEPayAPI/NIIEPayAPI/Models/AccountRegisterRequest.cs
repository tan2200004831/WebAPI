﻿namespace NIIEPayAPI.Models
{
    public class AccountRegisterRequest
    {
        public string AccountNumber { get; set; }
        public string AccountHolder { get; set; }
        public string Phone { get; set; }
        public string CitizenId { get; set; }
        public DateTime ExpiryDate { get; set; }
        public decimal InitialBalance { get; set; }
    }
}
