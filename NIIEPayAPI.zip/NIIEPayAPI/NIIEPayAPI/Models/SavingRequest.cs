﻿namespace NIIEPayAPI.Models
{
    public class SavingRequest
    {
        public string AccountNumber { get; set; }
        public decimal Amount { get; set; }
        public int TermMonths { get; set; }  // Kỳ hạn
        public bool AutoRenew { get; set; }  // Tự động gia hạn
    }
}
