﻿using Microsoft.AspNetCore.Mvc;

namespace NIIEPayAPI.Controllers
{
    public class SavingsWebController : Controller
    {
        public IActionResult SavingsList()
        {
            return View(); // Trả về Views/SavingsWeb/SavingsList.cshtml
        }
    }
}
