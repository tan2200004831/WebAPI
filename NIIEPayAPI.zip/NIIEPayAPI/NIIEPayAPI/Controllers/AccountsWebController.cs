﻿using Microsoft.AspNetCore.Mvc;

namespace NIIEPayAPI.Controllers
{
    public class AccountsWebController : Controller
    {
        [HttpGet("/register")]
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult AccountInfo()
        {
            return View(); // Trả về Views/AccountsWeb/AccountInfo.cshtml
        }
    }

}
