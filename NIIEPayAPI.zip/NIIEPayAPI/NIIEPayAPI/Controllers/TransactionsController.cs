﻿using Microsoft.AspNetCore.Mvc;
using NIIEPayAPI.Data;
using NIIEPayAPI.Models;

namespace NIIEPayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransactionsController : ControllerBase
    {
        private readonly NIIEPayContext _context;

        public TransactionsController(NIIEPayContext context)
        {
            _context = context;
        }

        // API lấy lịch sử giao dịch
        [HttpGet("history")]
        public IActionResult GetTransactionHistory(
            [FromQuery] string accountNumber,
            [FromQuery] DateTime from,
            [FromQuery] DateTime to)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
            if (account == null)
            {
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản" });
            }

            var history = _context.Transactions
                .Where(t => t.AccountNumber == accountNumber && t.TransactionTime >= from && t.TransactionTime <= to)
                .OrderByDescending(t => t.TransactionTime)
                .Select(t => new
                {
                    FullName = account.AccountHolder,
                    AccountNumber = account.AccountNumber,
                    TransactionId = t.TransactionId,
                    Amount = t.Amount,
                    Time = t.TransactionTime,
                    BalanceAfter = t.BalanceAfter,
                    Note = t.Note
                })
                .ToList();

            return Ok(new
            {
                status = "SUCCESS",
                total = history.Count,
                data = history
            });
        }
        [HttpPost("internal-transfer")]
        public IActionResult InternalTransfer([FromBody] TransferRequest request)
        {
            var sender = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.SenderAccount);
            var receiver = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.ReceiverAccount);

            if (sender == null || receiver == null)
            {
                return NotFound(new { status = "FAIL", message = "Tài khoản không hợp lệ" });
            }

            if (request.Amount <= 0)
            {
                return BadRequest(new { status = "FAIL", message = "Số tiền không hợp lệ" });
            }

            if (sender.AvailableBalance - request.Amount < 50000)
            {
                return BadRequest(new { status = "FAIL", message = "Tài khoản phải còn tối thiểu 50.000 VNĐ sau khi chuyển" });
            }

            // Cập nhật số dư
            sender.AvailableBalance -= request.Amount;
            receiver.AvailableBalance += request.Amount;

            // Ghi lại giao dịch
            _context.Transactions.Add(new Transaction
            {
                TransactionId = Guid.NewGuid().ToString(),
                AccountNumber = sender.AccountNumber,
                Amount = request.Amount,
                TransactionTime = DateTime.Now,
                BalanceAfter = sender.AvailableBalance,
                Note = request.Note,
                TransactionType = "CHUYEN_DI"
            });

            _context.Transactions.Add(new Transaction
            {
                TransactionId = Guid.NewGuid().ToString(),
                AccountNumber = receiver.AccountNumber,
                Amount = request.Amount,
                TransactionTime = DateTime.Now,
                BalanceAfter = receiver.AvailableBalance,
                Note = request.Note,
                TransactionType = "NHAN"
            });

            _context.SaveChanges();

            return Ok(new { status = "SUCCESS", message = "Chuyển khoản thành công" });
        }
        [HttpPost("external-transfer")]
        public IActionResult ExternalTransfer([FromBody] ExternalTransferRequest request)
        {
            var sender = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.SenderAccount);

            if (sender == null)
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản gửi" });

            if (request.Amount <= 0)
                return BadRequest(new { status = "FAIL", message = "Số tiền không hợp lệ" });

            if (sender.AvailableBalance - request.Amount < 50000)
                return BadRequest(new { status = "FAIL", message = "Tài khoản phải còn tối thiểu 50.000 VNĐ sau khi chuyển" });

            // Trừ tiền người gửi
            sender.AvailableBalance -= request.Amount;

            // Ghi giao dịch
            var transaction = new Transaction
            {
                TransactionId = Guid.NewGuid().ToString(),
                AccountNumber = request.SenderAccount,
                Amount = request.Amount,
                TransactionTime = DateTime.Now,
                BalanceAfter = sender.AvailableBalance,
                Note = $"{request.Note} (Chuyển đến {request.BankName})",
                TransactionType = "EXTERNAL"
            };

            _context.Transactions.Add(transaction);
            _context.SaveChanges();

            return Ok(new
            {
                status = "SUCCESS",
                message = "Chuyển khoản thành công",
                transactionId = transaction.TransactionId
            });
        }

    }
}
