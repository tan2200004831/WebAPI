﻿using Microsoft.AspNetCore.Mvc;
using NIIEPayAPI.Data;
using NIIEPayAPI.Models;

namespace NIIEPayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountsController : ControllerBase
    {
        private readonly NIIEPayContext _context;

        public AccountsController(NIIEPayContext context)
        {
            _context = context;
        }

        // [1] API đăng ký tài khoản - POST /api/accounts/register
        [HttpPost("register")]
        public IActionResult Register([FromBody] AccountRegisterRequest request)
        {
            // Kiểm tra trùng số tài khoản
            var existing = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.AccountNumber);
            if (existing != null)
            {
                return BadRequest(new
                {
                    status = "FAIL",
                    message = "Số tài khoản đã tồn tại"
                });
            }

            // Kiểm tra số dư ban đầu
            if (request.InitialBalance < 100000)
            {
                return BadRequest(new
                {
                    status = "FAIL",
                    message = "Số dư ban đầu phải từ 100.000 VNĐ"
                });
            }

            // Kiểm tra ngày hết hạn CCCD
            if (request.ExpiryDate < DateTime.Now)
            {
                return BadRequest(new
                {
                    status = "FAIL",
                    message = "Căn cước công dân đã hết hạn"
                });
            }

            // Tạo tài khoản mới
            var account = new Account
            {
                AccountNumber = request.AccountNumber,
                AccountHolder = request.AccountHolder,
                Phone = request.Phone,
                CitizenId = request.CitizenId,
                ExpiryDate = request.ExpiryDate,
                AvailableBalance = request.InitialBalance
            };

            _context.Accounts.Add(account);
            _context.SaveChanges();

            return Ok(new
            {
                status = "SUCCESS",
                accountId = account.AccountNumber,
                message = "Tạo tài khoản thành công"
            });
        }

        // [2] API xem thông tin tài khoản - GET /api/accounts/{accountNumber}
        [HttpGet("{accountNumber}")]
        public IActionResult GetAccountByNumber(string accountNumber)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);

            if (account == null)
            {
                return NotFound(new
                {
                    status = "FAIL",
                    message = "Không tìm thấy tài khoản"
                });
            }

            return Ok(new
            {
                status = "SUCCESS",
                data = new
                {
                    account.AccountNumber,
                    account.AccountHolder,
                    account.Phone,
                    account.CitizenId,
                    account.ExpiryDate,
                    account.AvailableBalance
                }
            });
        }
    }
}
