﻿using Microsoft.AspNetCore.Mvc;
using NIIEPayAPI.Data;
using NIIEPayAPI.Models;

namespace NIIEPayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SavingsController : ControllerBase
    {
        private readonly NIIEPayContext _context;

        public SavingsController(NIIEPayContext context)
        {
            _context = context;
        }

        [HttpPost("create")]
        public IActionResult CreateSaving([FromBody] SavingRequest request)
        {
            var account = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.AccountNumber);
            if (account == null)
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản" });

            if (request.Amount <= 0)
                return BadRequest(new { status = "FAIL", message = "Số tiền gửi phải lớn hơn 0" });

            if (account.AvailableBalance - request.Amount < 50000)
                return BadRequest(new { status = "FAIL", message = "Tài khoản phải còn tối thiểu 50.000 VNĐ sau khi gửi" });

            var interest = _context.InterestRates.FirstOrDefault(i => i.TermMonths == request.TermMonths);
            if (interest == null)
                return BadRequest(new { status = "FAIL", message = "Kỳ hạn không hợp lệ" });

            // Tính ngày bắt đầu và đáo hạn
            var startDate = DateTime.Now;
            var maturityDate = startDate.AddMonths(request.TermMonths);

            var saving = new Saving
            {
                SavingId = Guid.NewGuid().ToString(),
                AccountNumber = request.AccountNumber,
                Amount = request.Amount,
                TermMonths = request.TermMonths,
                InterestRate = (float)interest.InterestRatePercent,
                StartDate = startDate,
                MaturityDate = maturityDate,
                AutoRenew = request.AutoRenew
            };

            account.AvailableBalance -= request.Amount;

            _context.Savings.Add(saving);
            _context.SaveChanges();

            return Ok(new
            {
                status = "SUCCESS",
                message = "Gửi tiết kiệm thành công",
                savingId = saving.SavingId,
                maturityDate = saving.MaturityDate,
                interestRate = saving.InterestRate
            });
        }
        [HttpGet("list")]
        public IActionResult GetSavingsByAccount([FromQuery] string accountNumber)
        {
            var savings = _context.Savings
                .Where(s => s.AccountNumber == accountNumber)
                .Select(s => new
                {
                    s.SavingId,
                    s.Amount,
                    s.TermMonths,
                    s.InterestRate,
                    s.StartDate,
                    s.MaturityDate,
                    s.AutoRenew
                })
                .ToList();

            return Ok(new
            {
                status = "SUCCESS",
                data = savings
            });
        }

    }
}
