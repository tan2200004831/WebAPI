﻿using Microsoft.AspNetCore.Mvc;

namespace NIIEPayAPI.Controllers
{
    public class TransactionsWebController : Controller
    {
        // Hiển thị giao diện xem lịch sử giao dịch
        public IActionResult TransactionHistory()
        {
            return View(); // Mặc định sẽ tìm Views/TransactionsWeb/TransactionHistory.cshtml
        }
        public IActionResult Transfer()
        {
            return View(); // Trả về giao diện Views/TransactionsWeb/Transfer.cshtml
        }
        public IActionResult ExternalTransfer()
        {
            return View(); // Trả về giao diện Views/TransactionsWeb/ExternalTransfer.cshtml
        }

    }

}
