﻿using Microsoft.AspNetCore.Mvc;
using NIIEPayAPI.Data;
using NIIEPayAPI.Models;

namespace NIIEPayAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TransfersController : ControllerBase
    {
        private readonly NIIEPayContext _context;

        public TransfersController(NIIEPayContext context)
        {
            _context = context;
        }

        // API chuyển khoản nội bộ
        [HttpPost("internal")]
        public IActionResult InternalTransfer([FromBody] TransferRequest request)
        {
            if (request.Amount <= 0)
            {
                return BadRequest(new { status = "FAIL", message = "Số tiền phải lớn hơn 0" });
            }

            // Tìm người gửi
            var sender = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.SenderAccount);
            if (sender == null)
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản gửi" });

            // Tìm người nhận
            Account receiver;
            if (request.IsPhoneNumber)
            {
                receiver = _context.Accounts.FirstOrDefault(a => a.Phone == request.ReceiverAccount);
            }
            else
            {
                receiver = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.ReceiverAccount);
            }

            if (receiver == null)
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản nhận" });

            // Kiểm tra số dư còn lại phải ≥ 50.000
            if (sender.AvailableBalance - request.Amount < 50000)
            {
                return BadRequest(new { status = "FAIL", message = "Số dư sau chuyển phải còn ít nhất 50.000 VNĐ" });
            }

            // Trừ tiền và cộng tiền
            sender.AvailableBalance -= request.Amount;
            receiver.AvailableBalance += request.Amount;

            // Lưu transaction
            var transaction = new Transaction
            {
                TransactionId = Guid.NewGuid().ToString(),
                AccountNumber = sender.AccountNumber,
                Amount = request.Amount,
                TransactionTime = DateTime.Now,
                BalanceAfter = sender.AvailableBalance,
                Note = request.Note,
                TransactionType = "Internal Transfer"
            };

            _context.Transactions.Add(transaction);
            _context.SaveChanges();

            return Ok(new
            {
                status = "SUCCESS",
                message = "Chuyển khoản nội bộ thành công",
                transactionId = transaction.TransactionId
            });


        }
        [HttpPost("external")]
        public IActionResult ExternalTransfer([FromBody] ExternalTransferRequest request)
        {
            if (request.Amount <= 0)
            {
                return BadRequest(new { status = "FAIL", message = "Số tiền phải lớn hơn 0" });
            }

            // Tìm người gửi
            var sender = _context.Accounts.FirstOrDefault(a => a.AccountNumber == request.SenderAccount);
            if (sender == null)
                return NotFound(new { status = "FAIL", message = "Không tìm thấy tài khoản gửi" });

            // Kiểm tra số dư sau chuyển khoản ≥ 50.000
            if (sender.AvailableBalance - request.Amount < 50000)
            {
                return BadRequest(new { status = "FAIL", message = "Số dư sau chuyển phải còn ít nhất 50.000 VNĐ" });
            }

            // Trừ tiền người gửi
            sender.AvailableBalance -= request.Amount;

            // Ghi log giao dịch
            var transaction = new Transaction
            {
                TransactionId = Guid.NewGuid().ToString(),
                AccountNumber = sender.AccountNumber,
                Amount = request.Amount,
                TransactionTime = DateTime.Now,
                BalanceAfter = sender.AvailableBalance,
                Note = $"{request.Note} (Chuyển đến {request.BankName})",
                TransactionType = "External Transfer"
            };

            _context.Transactions.Add(transaction);
            _context.SaveChanges();

            return Ok(new
            {
                status = "SUCCESS",
                message = "Chuyển khoản liên ngân hàng thành công",
                transactionId = transaction.TransactionId
            });
        }
    }
}
