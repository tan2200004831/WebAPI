﻿using Microsoft.EntityFrameworkCore;
using NIIEPayAPI.Models;
using System.Collections.Generic;

namespace NIIEPayAPI.Data
{
    public class NIIEPayContext : DbContext
    {
        public NIIEPayContext(DbContextOptions<NIIEPayContext> options) : base(options)
        {
        }

        public DbSet<Account> Accounts { get; set; }
        public DbSet<Transaction> Transactions { get; set; }
        public DbSet<Saving> Savings { get; set; }
        public DbSet<InterestRate> InterestRates { get; set; }
    }
}
